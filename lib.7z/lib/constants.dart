import 'models/task.dart';
import 'models/user.dart';

late User userLog;

String errorLog = "";

late Task taskInMemory;